<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/registro.css"> 
    <title>Registro</title>
</head>
<body>
    <header>
        <a href="index.html"><h1>BAUHAUS</h1></a>
        <nav>
            <ul>
                <li><a href="secciones/arquitectura.html">Arquitectura</a></li>
                <li><a href="secciones/industrial.html">Industrial</a></li>
                <li><a href="secciones/mobiliario.html">Mobiliario</a></li>
                <li><a href="secciones/galeria.html">Galeria</a></li>
                <li><a href="inicio_de_sesion.php">Inicio de Sesión</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="form-container">
            <h2>Registro</h2>
            <form action="formulario.php" method="post"> 
                <div class="form-group">
                    <label for="fullname">Nombre Completo:</label>
                    <input type="text" id="fullname" name="fullname" required>
                </div>
                <div class="form-group">
                    <label for="email">Correo electrónico:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="phone">Teléfono:</label>
                    <input type="text" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="message">Mensaje:</label>
                    <textarea id="message" name="message" required></textarea>
                </div>
                <button type="submit">Registrarse</button>
            </form>
        </div>
    </main>

    <footer>
        <p>Contacto: info@bauhaus.com | Teléfono: +54 123456789</p>
        <p>Dirección: Calle de la Creatividad, 123, Weimar, Alemania</p>
        <p>&copy; 2024 Bauhaus Diseño.</p>
    </footer>
</body>
</html>
